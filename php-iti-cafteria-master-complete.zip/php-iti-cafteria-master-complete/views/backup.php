<tr>
        <td>
          <!-- first section  -->
            <div class="ac">
              <input class="ac-input" id="ac-1" name="ac-1" type="checkbox" />
              <label id ="firstRow" class="ac-label" for="ac-1"><?php echo $orders["resultset"][1]["date"] ?></label>

              <article class="ac-text" style="position: absolute;top: 80vh;left: 50vw;">
                  <div class="ac-sub">
                    <label for="ac-1">order date 1 </label>
                  </div>
              </article>
            </div>
          <!-- first section  -->
        </td>

        <td>Processing</td>
        <td>55 EGP</td>
        <td>Cancel</td>
      </tr>
      
      <tr>
        <td>
          <!-- second section  -->
            <div class="ac">
                <input class="ac-input" id="ac-4" name="ac-4" type="checkbox" />
                <label class="ac-label" for="ac-4">Nourhame sherif                    
                </label>
              
                <article class="ac-text" style="position: absolute;top: 80vh;left: 50vw;">
                  <div class="ac-sub">
                    <label for="ac-4">order date 2</label>
                  </div>
                </article>
              </div>
          <!-- second section  -->
        </td>
        <td>Out for delivery</td>
        <td>20 EGP</td>
        <td></td>
      </tr>